
import pickle
import logging
import math
import multiprocessing
import random
import time
import traceback
from typing import DefaultDict
import tqdm

from .common.api import API
from .common.triple_kb import TripleKB
from .common.seq_extractor import SeqExtractor


def generate_classes(library_list):
    extractor = SeqExtractor()
    try:
        (index, file_paths) = library_list
        api_infos = list()
        for file_path in tqdm.tqdm(file_paths):
            code = open(file_path, "r").read()
            package, class_name, class_apis, class_tokens = extractor.extract_method_class(code)
            if class_name is None or class_name == "<none>":
                continue
            lib_name = package + '.' + class_name
            api_infos.append((file_path, lib_name, class_name, class_apis, class_tokens))
    except Exception as e:
            logging.error(e)
            traceback.print_exc()  
    return api_infos
    
    
def annotate_class_apis(class_apis, res, op1, op2):
    op1_api = None
    op2_api = None
    resource = None
    if class_apis is None:
        return resource, op1_api, op2_api
    api:API
    for api in class_apis:
        _, cand_res, _, _ = api.res_op_annotate(res=res, op=op1, relax=True)
        if cand_res is not None:
            op1_api = api.api_name
            resource = cand_res
            continue
        _, cand_res, _, _ = api.res_op_annotate(res=res, op=op2, relax=True)
        if cand_res is not None:
            op2_api = api.api_name
            continue
    
    if op1_api is not None and op2_api is not None and op1_api.replace(op1, '') == op2_api.replace(op2, ''):
        return resource, op1_api, op2_api 
    else:
        return None, None, None
    
        

    
def mine(triple_kb: TripleKB, classes):
    op_dict = DefaultDict(list)
    for res, op1, op2 in triple_kb.triples:
        op_dict[(op1, op2)].append((res, op1, op2))
    v_lib = []
    api_dict = DefaultDict(set)
    
    for (file_path, lib_name, class_name, class_apis, class_tokens) in tqdm.tqdm(classes):
        if class_name == None or class_apis == None:
            continue
        try:
            for op1, op2 in op_dict.keys():
                if op1 in class_tokens and op2 in class_tokens:
                    for res, op1, op2 in op_dict[(op1, op2)]:
                        resource, op1_api, op2_api = annotate_class_apis(class_apis, res, op1, op2)     
                        if op1_api is not None and op2_api is not None:
                            v_lib.append(lib_name)
                            logging.info(f'file path:{file_path}')
                            logging.info(f'lib:{lib_name}')
                            logging.info(f'triple:{(res,op1,op2)}')
                            logging.info(f'class name is {class_name}')  
                            logging.info(f'resource is {resource}')
                            logging.info(f'api1 is {op1_api}') 
                            logging.info(f'api2 is {op2_api}')  
                            api_dict[lib_name].add((op1_api, op2_api))
        except Exception as e:
            logging.error(e)
            traceback.print_exc()
    return api_dict   
                

if __name__ == '__main__':
    LOG_FILE = 'log/{} MINE_CLASS'
    log_file =  LOG_FILE.format(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
    format = '[%(levelname)s] %(asctime)s-%(pathname)s[line:%(lineno)d]-%(message)s'
    logging.basicConfig(level=logging.INFO,format=format)
    formatter = logging.Formatter(format)
    file_handler = logging.FileHandler(filename=log_file,mode='w',encoding='utf-8')
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.INFO)
    logging.getLogger().addHandler(file_handler)

    # directory paths of the libraries
    library_list = []
    classes = generate_classes(library_list)


    triples_path = "triples.csv"
    triple_kb = TripleKB.init_from_csv(triples_path)
    api_dict = mine(triple_kb, classes)