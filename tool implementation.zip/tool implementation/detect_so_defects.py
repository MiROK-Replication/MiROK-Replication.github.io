import csv
from collections import defaultdict
import logging
import time
from .common.corpus import Corpus
from .common.triple_kb import TripleKB
from .common.triple_kb import TripleKB
from codetoolkit.javalang.tree import *
from codetoolkit.delimiter import Delimiter
from codetoolkit.javalang.parse import parse


def save_triples_to_csv(triples, csv_path):
    with open(csv_path, 'w', encoding='utf8', newline='') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(['resource', 'operator1', 'operator2'])
        for triple in triples:
            writer.writerow(triple) 
            
def unify_so_snippet(method):
        '''code: input a method or a class or code snippet ->
        a class header added and extracted by extractor '''
        try:
            ast = parse(method)
            for _, node in ast:
                if isinstance(node, ClassDeclaration):
                    return method 
        except Exception:
            try: 
                ast = parse(f"public class Foo {{{method}}}")
            except:
                return f"public class Foo {{ public void s(){{{method}}} }}"    
            return f"public class Foo {{{method}}}"  
    
def is_autoclosable(code, res):
    try:
        ast = parse(code)
    except:
        return 

    for _, node in ast.filter(TryStatement):
        if isinstance(node, TryStatement):
            try:
                type_name = Delimiter.split_camel(node.resources[0].type.name)
                name = Delimiter.split_camel(node.resources[0].name)
                if type_name.__contains__(res) or name.__contains__(res):
                    logging.info(f'autoclosable : {res} : \n{code}')
                    return True
            except:
                pass
                # logging.info(f'try no resources : {code} ')
    return False
                
def is_invalid_type(code, res):
    try:
        ast = parse(code)
    except:
        return 

    invalid_prefixes = {"String",}
    invalid_suffixes = {"String", "List", "Set", "Collection"}
    for _, declaration_node in ast.filter(MethodDeclaration):
        for parameter in declaration_node.parameters:
            if Delimiter.split_camel(parameter.name) == res:
                for prefix in invalid_prefixes:
                    if parameter.type.name.startswith(prefix):
                        return True
                for suffix in invalid_suffixes:
                    if parameter.type.name.endswith(suffix):
                        return True
    
    for _, declaration_node in ast.filter(FieldDeclaration):
        for declarator in declaration_node.declarators:
            if Delimiter.split_camel(declarator.name) == res:
                for prefix in invalid_prefixes:
                    if declaration_node.type.name.startswith(prefix):
                        return True
                for suffix in invalid_suffixes:
                    if declaration_node.type.name.endswith(suffix):
                        return True
        
    for _, declaration_node in ast.filter(LocalVariableDeclaration):
        for declarator in declaration_node.declarators:
            t = declaration_node.type.name if not hasattr(declaration_node.type, 'sub_type') or not declaration_node.type.sub_type else declaration_node.type.sub_type.name
            if Delimiter.split_camel(declarator.name) == res:
                for prefix in invalid_prefixes:
                    if t.startswith(prefix):
                        return True
                for suffix in invalid_suffixes:
                    if t.endswith(suffix):
                        return True

    return False

def detect_so_snippets(corpus: Corpus, triple_kb:TripleKB):
    for res, op1, op2 in triple_kb.triples:
        print(res, op1, op2)
        triple_kb.detect_triples[(res, op1)].add(op2)
    super_tirples = defaultdict(set)
    for res, op1, op2 in sorted(triple_kb.triples, key=lambda t: len(t[0].split()), reverse=True):
        words = res.split()
        for l in range(1, len(words)):
            for b in range(0, len(words) - l):
                e = b + l
                phrase = " ".join(words[b:e])
                if (phrase, op1, op2) in triple_kb.triples:
                    super_tirples[phrase, op1, op2].add((res, op1, op2))
    
    negatives = set()
    positives = set()
    negative_triples = set()
    positive_triples = set()
    negative_records = list()
    for res, op1 in sorted(triple_kb.detect_triples.keys(),key=lambda d: len(d[0].split()), reverse=True):                
        op2s = triple_kb.detect_triples[(res, op1)]
    
        seqs = corpus.get_res_op1_candidate_seqs(res, op1)
        for seq in seqs:
            has_valid_op2 = False  
            no_op2 = False  
            for op2 in op2s:
                jump = False 
                for super_res, _, _ in super_tirples[res, op1, op2]:
                    if (super_res, op1, seq) in negatives or (super_res, op1, seq) in positives:
                        jump = True
                        break
                if jump:
                    continue
                
                detect_ret = seq.detect(res, op1, op2)
                
                    
                if detect_ret == 1 or (detect_ret == 0 and is_autoclosable(seq.origin, res=res)) or (detect_ret == 0 and is_invalid_type(seq.origin, res=res)):
                    has_valid_op2 = True
                    # positives.add((res, op1, seq))
                    # positive_triples.add((res, op1, op2))

                    # logging.warn(f' positive triple: {(res,op1,op2s)}')
                    # logging.warn(f' positive snippet: \n {seq.origin}')
                elif detect_ret == 0 and not is_autoclosable(seq.origin, res=res) and not is_invalid_type(seq.origin, res=res): 
                    # negatives.add((res, op1, seq))
                    # negative_triples.add((res, op1, op2))
                    no_op2 = True
            if not has_valid_op2 and no_op2:
                op2_str = ''.join(list(op2s))
                negative_records.append([((res, op1, op2_str)), seq.origin])
                logging.warn(f' negative triple: {(res,op1,op2s)}')
                logging.warn(f' negative snippet: \n {seq.origin}')
    return negative_records

                          

if __name__ == '__main__':
    LOG_FILE = 'log/{} Detect defects'
    log_file =  LOG_FILE.format(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime()))
    format = '[%(levelname)s] %(asctime)s-%(pathname)s[line:%(lineno)d]-%(message)s'
    logging.basicConfig(level=logging.INFO,format=format)
    formatter = logging.Formatter(format)
    file_handler = logging.FileHandler(filename=log_file,mode='w',encoding='utf-8')
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.INFO)

    logging.getLogger().addHandler(file_handler)

    
    # build so code corpus. 
    # See common.corpus.Corpus.init_from_classes for building from classes
    classes = [] # list of java class codes
    corpus = Corpus.init_from_classes(classes)
    print(len(corpus.seqs))

    triples_path = "triples.csv"
    triple_kb = TripleKB.init_from_csv(triples_path)
    negative_records = detect_so_snippets(corpus, triple_kb)
    
   










    


    
       