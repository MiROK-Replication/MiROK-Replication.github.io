from collections import defaultdict
import csv

class PairKB:
    def __init__(self) -> None:
        self.pairs = set()
        self.op1s = set()
        self.op2s = set()
        self.op1_count = defaultdict(int)
        self.op2_count = defaultdict(int)

    @classmethod
    def init_from_csv(cls, csv_path):
        pair_kb = cls()
        with open(csv_path, newline='') as csv_file:
            reader = csv.DictReader(csv_file)
            for row in reader:   
                pair_kb.add_pair(row['op1'],row['op2'])
        return pair_kb
        
    def add_pair(self, op1, op2):
        self.pairs.add((op1, op2))
        self.op1s.add(op1)
        self.op2s.add(op2)
        self.op1_count[op1] += 1
        self.op2_count[op2] += 1

    def remove_pair(self, op1, op2):
        if (op1, op2) in self.pairs:
            print(self.op2s)
            self.pairs.remove((op1, op2))   
        self.op1_count[op1] -= 1
        self.op2_count[op2] -= 1
        if self.op1_count[op1] == 0:
            self.op1s.remove(op1)
        if self.op2_count[op2] == 0:
            self.op2s.remove(op2)

    def __str__(self):
        return "=============================== PAIRS KB ==============================\n" + \
                f'number of pairs: {len(self.pairs)}\n' + \
               '\n'.join(str(pair) for pair in sorted(self.pairs))
    
