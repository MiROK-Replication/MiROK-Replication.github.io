import logging
import re
import traceback

from codetoolkit.code_pos import CodePOS
from codetoolkit.delimiter import Delimiter

from .tag import Tag
from .token_type import TokenType

CODE_POS = CodePOS.get_inst()

class API:
    def __init__(self, caller, callee, args, retargs):
        self.caller = caller
        self.callee = callee
        self.args = args
        self.retargs = retargs
        self.token_list, self.token_type_list = [], []
        self.pos_list = []
        self.api_name = caller[0] + '.' + callee
        self.generate_token_seq()
        
    def __str__(self):
        return f"<API: {self.caller} | {self.callee} | {self.args} | {self.retargs}>"
    
    def generate_token_seq(self):
        self.token_list = []
        self.token_type_list = []
        self.pos_list = []
        if self.caller is not None:
            # caller = self.caller[0] if self.caller[0] != "<unknown>" else self.caller[1]
            caller = self.caller[1] if self.callee != '<init>' else self.retargs[0][1]
            caller = Delimiter.split_camel(caller).strip()
            # logging.info(self.caller[1])
        if self.callee is not None:
            try:
                callee = Delimiter.split_camel(self.callee).strip()
            except:
                logging.error(callee)
                logging.error(traceback.format_exc())
        if len(caller) != 0:
            for _ in caller.split(" "):
                self.token_list.append(_)
                self.token_type_list.append(TokenType.CALLER)
                self.pos_list.append('noun')
        if len(callee) != 0:
            tags = CODE_POS.tag(callee) if callee != "<init>" else [("<init>", "verb")]
            for token, pos in tags:
                self.token_list.append(token)
                self.token_type_list.append(TokenType.CALLEE)
                self.pos_list.append(pos)   

    def decode(self, tag_list):
        res, op1, op2 = None, None, None
        has_res = False
        has_op = False
        for i in range(0, len(tag_list)):
            tag = tag_list[i]
            if tag == Tag.RES and not has_res:
                index = i
                res = ""
                while index < len(tag_list) and tag_list[index] == Tag.RES :
                    res += " " + self.token_list[index]
                    index += 1
                res = res.strip()
                has_res = True
            elif tag == Tag.OP1:
                op1 = self.token_list[i]
                has_op = True
            elif tag == Tag.OP2:
                op2 = self.token_list[i]
                has_op = True
        if has_op:
            return res, op1, op2
        else:
            return None, None, None

    def res_op_annotate(self, res, op, relax=False):
        compound = " ".join(f"{token}-{type.value}-{pos}" for token, type, pos in zip(self.token_list, self.token_type_list, self.pos_list))
        
        pattern = r"(^|.+ )(%s)( .+|) (%s)( .+|$)" % (
            " ".join(f"{re.escape(word)}-CALLEE-verb" for word in op.split()),
            " ".join(f"{re.escape(word)}-CALLEE-noun" for word in res.split()))
        mobj = re.match(pattern, compound)
        if mobj:
            part1, part_op, part2, part_res, part3 = mobj.group(1), mobj.group(2), mobj.group(3), mobj.group(4), mobj.group(5)
            op_start = part1.count("-") // 2
            op_end = op_start + part_op.count("-") // 2
            res_start = op_end + part2.count("-") // 2
            res_end = res_start + part_res.count("-") // 2
            res_strs = part_res.split()
            for s in reversed(part2.split()):
                if s.endswith("-noun"):
                    res_strs.insert(0, s)
            for s in part2.split():
                if s.endswith("-noun"):
                    res_strs.append(s)
            cand_res = " ".join(s.split("-")[0] for s in res_strs)
            op_str = re.sub(r"\s+", " ", f"{part1} {part2} {part_res} {part3}").strip() if not relax else\
                    re.sub(r"\s+", " ", f"{part1} {part2} {part_res}").strip()
            return op_str, cand_res, (res_start, res_end), (op_start, op_end)
        
        pattern = r"(^|.+ )(%s)( .+|) (%s)( .+|$)" % (
            " ".join(f"{re.escape(word)}-CALLER-noun" for word in res.split()),
            " ".join(f"{re.escape(word)}-CALLEE-verb" for word in op.split()))
        mobj = re.match(pattern, compound)
        
        if mobj:
            part1, part_res, part2, part_op, part3 = mobj.group(1), mobj.group(2), mobj.group(3), mobj.group(4), mobj.group(5)
            
            if len(part3) > 0 and part3.split()[0].endswith("-noun"):
                return None, None, (-1, -1), (-1, -1)

            res_start = part1.count("-") // 2
            res_end = res_start + part_res.count("-") // 2
            op_start = res_end + part2.count("-") // 2
            op_end = op_start + part_op.count("-") // 2
            cand_res = " ".join(s.split("-")[0] for s in part1.split() + part_res.split())
            op_str = re.sub(r"\s+", " ", f"{part1} {part_res} {part2} {part3}").strip() if not relax else \
                    re.sub(r"\s+", " ", f"{part1} {part_res} {part2}").strip()
            return op_str, cand_res, (res_start, res_end), (op_start, op_end)

        
        return None, None, (-1, -1), (-1, -1)

    def res_op_annotate_for_detect(self, res, op):
        compound = " ".join(f"{token}-{type.value}-{pos}" for token, type, pos in zip(self.token_list, self.token_type_list, self.pos_list))
        pattern = r"^(%s) (%s)( .+|$)" % (
            " ".join(f"{re.escape(word)}-CALLER-noun" for word in res.split()),
            " ".join(f"{re.escape(word)}-CALLEE-verb" for word in op.split()))
        mobj = re.match(pattern, compound)
        if mobj:
            part_res, part_op, rest = mobj.group(1), mobj.group(2), mobj.group(3)
            eles = []
            for ele in rest.split():
                if ele.split("-")[-1] == "noun":
                    eles.append(ele)
                else:
                    break
            
            rest_noun = ' '.join(eles)
            if len(rest_noun) > 0:
                return None
            return rest_noun
        pattern = r"(^|.+ )(%s) (%s)( .+|$)" % (
            " ".join(f"{re.escape(word)}-CALLEE-verb" for word in op.split()),
            " ".join(f"{re.escape(word)}-CALLEE-noun" for word in res.split()))
        mobj = re.match(pattern, compound)
        if mobj:
            obj, part_op, part_res, rest = mobj.group(1), mobj.group(2), mobj.group(3), mobj.group(4)
            rest_eles = rest.split()
            if len(rest_eles) > 0 and rest_eles[0].split("-")[-1] == "noun":
                return None
            return f"{obj} {part_res}"
        return None
        
    def annotate(self,res,op1,op2,detect_mode=False):
        i = 0
        tag_list = [Tag.NONE] * len(self.token_list)
        has_res = False
        has_op = False
        list_len = len(self.token_list)
        while i < list_len:
            token = self.token_list[i]
            token_type = self.token_type_list[i]
            if token == op1 and token_type == TokenType.CALLEE:
                has_op = True
                tag_list[i] = Tag.OP1 
            elif token == op2 and token_type == TokenType.CALLEE:
                has_op = True
                tag_list[i] = Tag.OP2   
            else:
                if detect_mode:
                    next_token_type_change = False
                    if i+1<list_len and self.token_type_list[i+1] != token_type:
                        next_token_type_change = True
                    if next_token_type_change:
                        if token == res:
                            has_res = True
                            tag_list[i] = Tag.RES
                        elif res.endswith(token):
                            pos = len(res)
                            from_index = i
                            to_index = i
                            while res[:pos].endswith(token) and pos >= 0 and from_index >= 0:               
                                pos -= len(token)
                                from_index -= 1
                                token = self.token_list[from_index] 
                            if pos == 0:
                                has_res = True
                                for _ in range(from_index, to_index):
                                    tag_list[_] = Tag.RES  
                else:
                    words = res.split()
                    if len(words) + i > list_len:
                        i += 1
                        continue
                    tokens = [self.token_list[i+word_idx] for word_idx in range(len(words))]
                    if all(w == t for w, t in zip(words, tokens)):
                        has_res = True
                        for w_idx in range(len(words)):
                            tag_list[i+w_idx] = Tag.RES
                        i += len(words)
                        continue
            i += 1
        if not (has_op and has_res):
            tag_list = [Tag.NONE] * len(self.token_list)    
        return tag_list
