#!/usr/bin/env python
# -*- encoding: utf-8 -*-

import time
from typing import List

import logging
from codetoolkit.javalang.parse import parse
from codetoolkit.javalang.tree import *
from .api import API
from .seq import Seq

class SeqExtractor:
    
    def __init__(self):
        self.ast_error_num = 0

    def extract_ret_args(self, declaration_map, memeber_reference):
        arg = []
        try:
            arg_name = memeber_reference.member
            
            if arg_name in declaration_map.keys():
                arg.append([declaration_map[arg_name], arg_name])
            else:
                arg.append(["<unknown>", arg_name])
            return arg
        except:
            arg.append(["<unknown>", "<none>"])
            return arg
    
    def extract_method_parameters(self, node):
        params = []
        for parameter in node.parameters:
            if isinstance(parameter, FormalParameter):
                param = [parameter.type.name ,parameter.name]
                params.append(param)   
        return params
    
    def extract_method_arguments(self, declaration_map, inovcation_node):
        args = []
        for argument in inovcation_node.arguments:
            if isinstance(argument, MemberReference):
                arg = argument.member
                if arg in declaration_map.keys():
                    args.append([declaration_map[arg], arg])
                else:
                    args.append(["<unknown>", arg])
        return args
    
    def extract_const_str(self, code):
        hard_code = []
        try:
            ast = parse(code)
        except:
            # logging.error(f'error code is ~ { code }')
            # logging.error("syntax error, continue to process next code snippet!")
            print("syntax error, continue to process next code snippet!")
            return
        for _, node in ast.filter((MethodInvocation, Assignment, Declaration)):
            if isinstance(node, FieldDeclaration):
                for declarator in node.declarators:
                    if isinstance(declarator.initializer, Literal):
                        if 'final' in node.modifiers or node.type.name == "string" or node.type.name == "int" or node.type.name == "float" or node.type.name == "long":
                            hard_code.append(declarator.initializer.value)
                    elif isinstance(declarator.initializer, ClassCreator):
                        for arg in declarator.initializer.arguments:
                            if isinstance(arg, Literal):
                                hard_code.append(arg.value)     
            elif isinstance(node, VariableDeclaration):
                for declarator in node.declarators:
                    if isinstance(declarator.initializer, Literal):
                        if 'final' in node.modifiers or node.type.name == "string" or node.type.name == "int" or node.type.name == "float" or node.type.name == "long" or declarator.name.isupper():
                            hard_code.append(declarator.initializer.value)
                    elif isinstance(declarator.initializer, ClassCreator):
                        for arg in declarator.initializer.arguments:
                            if isinstance(arg, Literal):
                                hard_code.append(arg.value)
            elif isinstance(node, Assignment):
                if isinstance(node.value, Literal):
                    hard_code.append(node.value.value)
                elif isinstance(node.value, ClassCreator):
                        for arg in node.value.arguments:
                            if isinstance(arg, Literal):
                                hard_code.append(arg.value)
            elif isinstance(node, MethodInvocation):
                for arg in node.arguments:
                        if isinstance(arg, Literal):
                            hard_code.append(arg.value)
            elif isinstance(node, ClassCreator):
                        for arg in node.arguments:
                            if isinstance(arg, Literal):
                                hard_code.append(arg.value)
        return hard_code
    
    def extract_variable_declaration(self, ast):
         # generate declaration variables list
        declaration_map = dict()
        for _, declaration_node in ast.filter(MethodDeclaration):
            for parameter in declaration_node.parameters:
                declaration_map[parameter.name] = parameter.type.name
        
        for _, declaration_node in ast.filter(FieldDeclaration):
            for declarator in declaration_node.declarators:
                declaration_map[declarator.name] = declaration_node.type.name 
          
        for _, declaration_node in ast.filter(LocalVariableDeclaration):
            for declarator in declaration_node.declarators:
                declaration_map[declarator.name] = declaration_node.type.name if not hasattr(declaration_node.type, 'sub_type') or not declaration_node.type.sub_type else declaration_node.type.sub_type.name
     
        return declaration_map 
    
    def extaract_one_method(self, method_node, declaration_map):
        apis = list()
        # save lines which have been extracted as declaration to avoid extracted repeatly in invocation 
        ignore = set()
        
        for _, node in method_node.filter((MethodInvocation, ClassCreator, Assignment, Declaration)):
            if isinstance(node, LocalVariableDeclaration):
                for declarator in node.declarators:
                    if isinstance(declarator.initializer, MethodInvocation):
                        params = self.extract_method_arguments(declaration_map, declarator.initializer)
                        retarg = [[node.type.name, declarator.name]]
                        caller_name = '<none>' if declarator.initializer.qualifier == "" or declarator.initializer.qualifier == None else declarator.initializer.qualifier
                        if caller_name in declaration_map.keys():
                            caller  = [str(declaration_map[caller_name]), caller_name]
                        else:
                            caller  = ["<unknown>", caller_name]
                        api = API(caller, declarator.initializer.member,params,retarg)
                        apis.append(api)
                        ignore.add(declarator.initializer.begin_pos[0])
                        
                    elif isinstance(declarator.initializer, ClassCreator):
                        new_resource_type = declarator.initializer.type.name if declarator.initializer.type.name!=None else '<none>'
                        if new_resource_type in declaration_map.keys():
                            caller  = [str(declaration_map[new_resource_type]),new_resource_type]
                        else:
                            caller  = ["<unknown>", new_resource_type]
                        retargs = [[node.type.name, declarator.name]]    
                        params = self.extract_method_arguments(declaration_map,declarator.initializer)
                        api = API(caller, '<init>', params ,retargs)
                        apis.append(api)
                        ignore.add(declarator.initializer.begin_pos[0])
                       
            elif isinstance(node, Assignment):
                assignment_left = node.expressionl
                assignment_right = node.value
                
                if isinstance(assignment_right, ClassCreator):
                    new_resource_type = assignment_right.type.name if assignment_right.type.name!=None else '<none>'
                    if new_resource_type in declaration_map.keys():
                        caller  = [str(declaration_map[new_resource_type]),new_resource_type]
                    else:
                        caller  = ["<unknown>", new_resource_type]
                    retargs = self.extract_ret_args(declaration_map,assignment_left)    
                    params = self.extract_method_arguments(declaration_map,assignment_right)
                    api = API(caller, '<init>', params ,retargs)
                    apis.append(api)
                    ignore.add(assignment_right.begin_pos[0])
                elif isinstance(assignment_right, MethodInvocation):
                    params = self.extract_method_arguments(declaration_map,assignment_right)
                    retarg = self.extract_ret_args(declaration_map,assignment_left)

                    caller_name = '<none>' if assignment_right.qualifier =='' or assignment_right.qualifier == None else assignment_right.qualifier
                    # 获取变量类型信息
                    if caller_name in declaration_map.keys():
                        caller  = [str(declaration_map[caller_name]),caller_name]
                    else:
                        caller  = ["<unknown>", caller_name]
                    api = API(caller, assignment_right.member,params,retarg)
                    apis.append(api)
                    ignore.add(assignment_right.begin_pos[0])
            elif isinstance(node, ClassCreator) and node.begin_pos[0] not in ignore:
                new_resource_type = node.type.name if node.type.name!=None else '<none>'
                
                if new_resource_type in declaration_map.keys():
                    caller  = [str(declaration_map[new_resource_type]),new_resource_type]
                else:
                    caller  = ["<unknown>", new_resource_type]
                params = self.extract_method_arguments(declaration_map,node)
                api = API(caller, '<init>', params, [["<unknown>", "<none>"]])
                apis.append(api)
            elif isinstance(node, MethodInvocation) and node.begin_pos[0] not in ignore:
                params = self.extract_method_arguments(declaration_map, node)
                caller_name = '<none>' if node.qualifier == "" or node.qualifier == None else node.qualifier
                
                if caller_name in declaration_map.keys():
                    caller  = [str(declaration_map[caller_name]),caller_name]
                else:
                    caller  = ["<unknown>", caller_name]
                api = API(caller,node.member, params, [["<unknown>", "<none>"]])
                apis.append(api)
        # for api in apis:
        #     print(api)
        return method_node.name, apis
      
    def extract_method_class(self, code)-> List[API]:
        class_tokens = []
        class_apis = list()
        class_name = "<none>"
        try:
            ast = parse(code)
        except:
            # logging.error(f'error code is { code }')
            # logging.error("syntax error, continue to process next code snippet!")
            return None, None, None
        for _, node in ast.filter((ConstructorDeclaration, MethodDeclaration, ClassDeclaration, InterfaceDeclaration)):
            if isinstance(node, ClassDeclaration) or isinstance(node, InterfaceDeclaration):
                class_name = node.name
            elif isinstance(node, ConstructorDeclaration):
                params = self.extract_method_parameters(node)
                ret_type = class_name
                class_api = API([class_name, class_name], "<init>", params, [[ret_type, "<none>"]])
                class_apis.append(class_api)
                class_tokens.extend(class_api.token_list)
            elif isinstance(node, MethodDeclaration):
                params = self.extract_method_parameters(node) 
                if node.return_type is not None:
                    ret_type = node.return_type.name
                else:
                    ret_type = "<unknown>"
                class_api = API([class_name, class_name], node.name, params, [[ret_type, "<none>"]])
                class_apis.append(class_api)
                class_tokens.extend(class_api.token_list)
                # print(class_api)
                # print(len(class_api.token_list))
                # print(class_api.token_list)
        return class_name, class_apis, class_tokens
    
    def extract_one_class(self, code, back_level = 3) -> List[Seq]: 
        seqs = []
        try:
            ast = parse(code)
        except:
            # logging.error(f'error code is ~ { code }')
            # logging.error("syntax error, continue to process next code snippet!")
            self.ast_error_num += 1
            return seqs

        # generate declaration variables list
        declaration_map = self.extract_variable_declaration(ast)
        method_api_dict = dict()
        for _, node in ast.filter(MethodDeclaration):
            name, apis = self.extaract_one_method(node, declaration_map)
            method_api_dict[name] = apis
            
        self.back_trace(method_api_dict, back_level)
        for apis in method_api_dict.values():
            seq = Seq(code, apis)
            seqs.append(seq)
        return seqs

    def back_trace(self, method_api_dict, back_level=3):
        if back_level == 0:
            return
        merged = set()
        for name, apis in method_api_dict.items():
            positions = []
            replacements = []
            for idx, api in enumerate(apis):
                if api.callee != name and api.callee in method_api_dict:
                    positions.append(idx)
                    replacements.append(method_api_dict[api.callee])
                    merged.add(api.callee)
            new_apis = []
            begin_pos = 0
            for pos, rep in zip(positions, replacements):
                new_apis.extend(apis[begin_pos:pos])
                new_apis.extend(rep)
                begin_pos = pos + 1
            new_apis.extend(apis[begin_pos:len(apis)])
            method_api_dict[name] = new_apis
        for name in merged:
            method_api_dict.pop(name)
        if len(merged) == 0:
            return
        self.back_trace(method_api_dict, back_level-1)

if __name__ == '__main__':
    #   public static final String SATURDAY;
         
    #     string s = "m.txt";
    #     String SUNDAY = "SUNDAY";
    #     float PI = 34;
        # final double PI = 3.14;
    code = '''
     public class Foo {
        Foo(int a){
            this.a = a;
        }
        void g() {
            MD md;
            byte[] digest = md.digest();
           DigestInputStream dis = new DigestInputStream(is, md); 
         }
        }
    '''
    print(SeqExtractor().extract_method_class(code))