

from collections import defaultdict
import csv

class TripleKB:
    def __init__(self,):
        # use to annotate api
        # dict() res:op
        self.triples = set()
        # seq if api taged and res same    
        self.op1s = set()
        self.op2s = set()
        self.op1_count = defaultdict(int)
        self.op2_count = defaultdict(int)
        self.detect_triples = defaultdict(set)
    

    def add_triple(self, resource, op1, op2):
        self.triples.add((resource, op1, op2))
        self.op1s.add(op1)
        self.op2s.add(op2)
        self.op1_count[op1] += 1
        self.op2_count[op2] += 1

    def remove_triple(self, resource, op1, op2):
        if (resource, op1, op2) in self.triples:
            self.triples.remove((resource, op1, op2))
        self.op1_count[op1] -= 1
        self.op2_count[op2] -= 1
        if self.op1_count[op1] == 0:
            self.op1s.remove(op1)
        if self.op2_count[op2] == 0:
            self.op2s.remove(op2)

    def is_conflict(self, resource, op1, op2):
        return op1 in self.op2s or op2 in self.op1s

    @classmethod
    def init_from_csv(cls, csv_path):
        res_kb = cls()
        with open(csv_path, newline='') as csv_file:
            reader = csv.DictReader(csv_file)
            for row in reader:    
                res_kb.add_triple(row['resource'].strip(), row['operator1'].strip(), row['operator2'].strip())
        return res_kb

    def __str__(self):
        return "=============================== RESOURCE KB ==============================\n" + \
                f'number of triples: {len(self.triples)}\n' + \
               '\n'.join(str(triple) for triple in sorted(self.triples))

