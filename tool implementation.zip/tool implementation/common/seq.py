
from typing import List
from .api import API
from .tag import Tag

class Seq:
    def __init__(self, origin, api_seq:List[API]):
        self.origin = origin
        self.api_seq = api_seq  
        self.generate_token_seq()
        self.tag_seqs = []

    def generate_token_seq(self):
        self.token_seq, self.token_type_seq = [],[]
        for api in self.api_seq:
            token_list, type_list = api.token_list, api.token_type_list
            if token_list is not None:
                self.token_seq += token_list
                self.token_type_seq += type_list

    def valid(self):
        return len(self.tag_seqs) > 0

    def detect(self, res, op1, op2):
        acquired = set()
        released = set()
        for api in self.api_seq:
            op1_s = api.res_op_annotate_for_detect(res, op1)
            op2_s = api.res_op_annotate_for_detect(res, op2)
            if op1_s is not None:
                acquired.add(op1_s)
            if op2_s is not None and op2_s in acquired:
                released.add(op2_s)
            
        if len(acquired - released) != 0:
            return 0
        elif len(acquired) > 0:
            return 1
        return 2

    def expand_res(self, res, op1, op2):
        op1_str = None
        op2_str = None
        op1_api = None
        op2_api = None
        cand_res1 = None
        cand_res2 = None

        for api in self.api_seq:
            op_str, cand_res, _, _ = api.res_op_annotate(res=res, op=op1)
            if op_str is not None:
                op1_str = op_str
                op1_api = api
                cand_res1 = cand_res
                continue
            op_str, cand_res, _, _ = api.res_op_annotate(res=res, op=op2)
            if op_str is not None:
                op2_str = op_str
                op2_api = api
                cand_res2 = cand_res
                continue
                
        if op1_str is not None and op2_str is not None and op1_str == op2_str and cand_res1 == cand_res2:
            # logging.info([op1_method_name,op2_method_name])
            # logging.info([op1_str, op2_str])
            # logging.info(f'attention:{tag_seq}')
            # print(op1_api, "|", op2_api, "|", cand_res1)
            return cand_res1
        return None
   
    def annotate(self, res, op1, op2, conf=1):
        tag_seq = []
        op1_str = None
        op2_str = None
        op1_api = None
        op2_api = None
        for api in self.api_seq:
            api_tag_seq = [Tag.NONE] * len(api.token_list)
            op_str, _, (res_start, res_end), (op_start, op_end) = api.res_op_annotate(res=res, op=op1)
            if op_str is not None:
                op1_str = op_str
                op1_api = api
                api_tag_seq[res_start:res_end] = [Tag.RES] * (res_end - res_start)
                api_tag_seq[op_start:op_end] = [Tag.OP1] * (op_end - op_start)
                tag_seq.extend(api_tag_seq)
                continue
            op_str, _, (res_start, res_end), (op_start, op_end) = api.res_op_annotate(res=res, op=op2)
            if op1_str is not None and op_str is not None:
                op2_str = op_str
                op2_api = api
                api_tag_seq[res_start:res_end] = [Tag.RES] * (res_end - res_start)
                api_tag_seq[op_start:op_end] = [Tag.OP2] * (op_end - op_start)
                tag_seq.extend(api_tag_seq)
                continue
            tag_seq.extend(api_tag_seq)
                
        if op1_str is not None and op2_str is not None and op1_str == op2_str:
            self.tag_seqs.append((tag_seq, conf))
        
    def get_resources(self): 
        resources = set()
        ana_data = list()
        for tag_seq, conf in self.tag_seqs:
            i = 0
            resource = ""  
            while i < len(tag_seq):
                while i < len(tag_seq) and tag_seq[i] == Tag.RES :
                    resource += " " + self.token_seq[i]
                    i += 1
                if resource:
                    break
                i += 1
            resource = resource.strip()
            if len(resource) > 0:
                resources.add((resource, conf))      
                ana_data.append(([resource,self.token_seq,tag_seq], conf))   
        return  ana_data, resources

    def get_op_pairs(self):
        pairs = list()
        for tag_seq, conf in self.tag_seqs:
            OP1 = None
            OP2 = None
            for tag, token in zip(tag_seq, self.token_seq):
                if tag == Tag.OP1:
                    OP1 = token
                elif OP1 and tag == Tag.OP2:
                    OP2 = token
            if OP1 and OP2:
                pairs.append((OP1, OP2, conf))
                # pairs.append(([OP1, OP2], conf))
        return pairs
    
    def get_triples_with_conf(self):
        triples = set()
        for tag_seq, conf in self.tag_seqs:
            res, op1, op2 = None, None, None
            for api in self.api_seq:
                _res, _op1, _op2 = api.decode(tag_seq[:len(api.token_list)])
                res = _res if _res else res
                op1 = _op1 if _op1  else op1
                op2 = _op2 if op1 and _op2 else op2
                tag_seq = tag_seq[len(api.token_list):]
            
            if res and op1 and op2:
                triples.add((res, op1, op2, conf))
                break
        return triples

    def get_triples(self):
        #  ensure op1 is before op2
        triples = set()
        for tag_seq, _ in self.tag_seqs:
            res, op1, op2 = None, None, None
            for api in self.api_seq:
                _res, _op1, _op2 = api.decode(tag_seq[:len(api.token_list)])
                res = _res if _res else res
                op1 = _op1 if _op1  else op1
                op2 = _op2 if op1 and _op2 else op2
                tag_seq = tag_seq[len(api.token_list):]
            
            if res and op1 and op2:
                triples.add((res, op1, op2))
                break
        return triples

    def get_pairs_with_conf(self,predict_mode=False):
        pairs = set()
        for tag_seq, conf in self.tag_seqs:
            op1,op2 = None,None
            for api in self.api_seq:
                _op1,_op2 =  api.pair_decode(tag_seq[:len(api.token_list)])
                op1 = _op1 if _op1 else op1
                op2 = _op2 if op1 and _op2 else op2
                tag_seq = tag_seq[len(api.token_list):]
            if op1 and op2:
                pairs.add((op1,op2,conf))
                break
        return pairs
    
    def get_reses_with_conf(self):
        seq_reses = set()
        for tag_seq, conf in self.tag_seqs:
            for api in self.api_seq:
                reses = api.res_decode(tag_seq[:len(api.token_list)])  
                tag_seq = tag_seq[len(api.token_list):]
                if reses is not None:
                    for res in reses:
                        seq_reses.add((res,conf))
        return seq_reses

    def clear_tag(self):
        self.tag_seqs = list()

    def __str__(self):
        # return f"<Seq: api_seq={str([str(api) for api in self.api_seq])}, tag_seq={str([str(tag) for tag in self.tag_seq])}>"
        return f"<Seq origin:{self.origin}|token: {self.token_seq} | tag:{self.tag_seqs} |token type :{self.token_type_seq}>"
