#!/usr/bin/env python
# -*- encoding: utf-8 -*-

from abc import ABCMeta, abstractmethod

class Pipe(metaclass=ABCMeta):
    def __init__(self, name):
        self.name = name

    def __call__(self, *args):
        return self.pipe(*args)

    @abstractmethod
    def pipe(self, input):
        pass