from enum import Enum, unique
@unique
class Tag(Enum):
    RES = "resource"
    RES_B = "resource-b"
    RES_I = "resource-i"
    OP1 = "operation 1"
    OP1_B = "operation 1-b"
    OP1_I = "operation 1-i"
    OP2 = "operation 2"
    OP2_B = "operation 2-b"
    OP2_I = "operation 2-i"
    NONE = "none"
    