from enum import Enum, unique
@unique
class TokenType(Enum):
    CALLEE = "CALLEE"
    CALLER = "CALLER"
    PARANAME = "PARANAME"
    PARATYPE = "PARATYPE"
    CALLER_TYPE = "CALLER_TYPE"
