from collections import defaultdict
import csv

class ResKB:
    def __init__(self) -> None:
        self.reses = set()
        self.res_count = defaultdict(int)

    @classmethod
    def init_from_csv(cls, csv_path):
        res_kb = cls()
        with open(csv_path, newline='') as csv_file:
            reader = csv.DictReader(csv_file)
            for row in reader:   
                res_kb.add_res(row['resource'])
        return res_kb
        
    def add_res(self, res):
        self.reses.add(res)
        self.res_count[res] += 1

    def remove_res(self, res):
        if res in self.reses:
            self.reses.remove(res)   
        self.res_count[res] -= 1
        if self.res_count[res] == 0:
            self.reses.remove(res)
            
    def __str__(self):
        return "=============================== RESES KB ==============================\n" + \
                f'number of resources: {len(self.reses)}\n' + \
               '\n'.join(str(res) for res in sorted(self.reses))
    
